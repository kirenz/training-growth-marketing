# Auftrag für den Agenten: Daten und Hypothese

Kopiere den Text unter der Linie in den Chat von Antigravity.

---

Kontext: Die Datei webinar-kontakte-330.csv enthält die Anmeldungen zu drei Webinaren der fiktiven Beratung Aurenta, eine Zeile pro Kontakt, mit Teilnahme, Anliegen-Kategorie, Kontaktfreigabe und dem weiteren Verlauf (Follow-up gesendet, Antwort, Gespräch gebucht, Gespräch durchgeführt). Aurenta schickt heute allen Kontakten dieselbe Einladung zum Erstgespräch.

Aufgabe: Werte die Datei aus und beantworte drei Fragen mit Zahlen: An welcher Stelle des Kundenwegs gehen die meisten Kontakte verloren? Welche Anliegen-Kategorien buchen selten ein Gespräch, welche vergleichsweise oft? Welche Änderung an der Nachbereitung könnte Aurenta selbst vornehmen? Formuliere daraus eine Hypothese nach dem Muster „Wenn wir X ändern, dann Y, weil Z“ und nenne die Kennzahl, an der man sie prüfen würde.

Format: Eine kurze Datei auswertung.md mit den Tabellen (jeweils Zähler und Nenner angeben), der Hypothese und der Kennzahl. Diagramme sind nicht nötig.

Prüfung: Nur Aussagen, die sich aus der Datei belegen lassen. Wenn die Daten für eine Frage nicht reichen, das sagen, statt zu schätzen.
