# Auftrag für den Agenten

Kopiere den Text unter der Linie in den Chat von Antigravity, nachdem dieser Ordner als Projekt geöffnet ist.

---

Kontext: In diesem Ordner liegt der Soll-Prozess der Webinar-Nachbereitung der fiktiven Beratung Aurenta als BPMN-Datei (aurenta-webinar-soll.bpmn). Die Datei 01-followup-starter.json ist ein funktionierender n8n-Workflow aus demselben Kurs und zeigt, wie Knoten, Verbindungen und der Prompt aufgebaut sind. Die Datei prompt-n8n.txt enthält die vollständige Anweisung für den KI-Schritt.

Aufgabe: Erzeuge aus dem BPMN-Prozess einen importierbaren n8n-Workflow als Datei aurenta-soll.json. Jeder Schritt in der Bahn „Workflow-System“ und „KI-Agent“ wird ein Knoten, die Knotennamen entsprechen den Schrittnamen aus der BPMN-Datei (ohne Umlaute). Schritte in der Bahn „Marketing-Team“ bekommen keinen Knoten, der Workflow endet davor. Nutze dieselben Knotentypen und typeVersion wie im Muster: Manual Trigger, Edit Fields (Set), If für die Kontaktsperre, Basic LLM Chain mit Google Gemini Chat Model und dem Prompt aus prompt-n8n.txt. Der Kontakt K-01 wird wie im Muster als feste Felder eingetragen.

Format: Eine JSON-Datei mit den Feldern name, nodes, connections, active (false), settings, pinData. Dazu eine Tabelle in einer Datei zuordnung.md: BPMN-Schritt, n8n-Knoten, Knotentyp. Keine Zugangsdaten in der Datei, keine Versand-, Buchungs- oder Schreibknoten.

Prüfung: Nenne am Ende, welche Schritte aus dem BPMN nicht eins zu eins abgebildet werden konnten und warum. Erfinde keine Knotentypen, die nicht im Muster vorkommen. Wenn etwas unklar ist, frage nach, statt anzunehmen.
