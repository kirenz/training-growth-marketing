# Startordner für Übung 1.3

- aurenta-webinar-soll.bpmn: die Ablaufskizze mit KI-Agent, wie auf der Folie
- 01-followup-starter.json: ein laufender n8n-Workflow als Muster
- prompt-n8n.txt: die Anweisung für den KI-Schritt
- AUFTRAG.md: der Auftrag an den Agenten zum Kopieren

Ergebnis des Agenten: aurenta-soll.json und zuordnung.md. Beides kommt in die Teamablage.
