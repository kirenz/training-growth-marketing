# Startordner für Dienstag

- AUFTRAG.md: Auftrag 1, Workflow aus der Ablaufskizze bauen
- AUFTRAG-DATEN.md: Auftrag 2, Daten auswerten und Hypothese ableiten
- aurenta-webinar-soll.bpmn: die Ablaufskizze mit KI-Agent
- 01-followup-starter.json: ein laufender n8n-Workflow als Muster
- prompt-n8n.txt: die Anweisung für den KI-Schritt
- webinar-kontakte-330.csv: Export der drei Webinare, eine Zeile pro Kontakt

Ergebnisse des Agenten kommen in die Teamablage.
